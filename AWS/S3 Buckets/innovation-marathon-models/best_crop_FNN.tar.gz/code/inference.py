import torch
import json


def model_fn(model_dir):
    model = torch.load(r'/opt/ml/model/best_crop_predictor.pth')
    return model


def input_fn(request_body, request_content_type):
    request_body = json.loads(request_body)
    input = [request_body['Nitrogen'], request_body['Phosphorous'], request_body['Potassium'], request_body['Temperature'],
             request_body['Humidity'], request_body['pH'], request_body['rainfall']]
    return torch.tensor(input)


def predict_fn(input_data, model):
    model.eval()
    with torch.no_grad():
        return model(input_data)


def output_fn(prediction, content_type):
    labels = ['Rice', 'Maize', 'Chickpea', 'Kidneybeans', 'Pigeonpeas',
              'Mothbeans', 'Mungbean', 'Blackgram', 'Lentil', 'Pomegranate',
              'Banana', 'Mango', 'Grapes', 'Watermelon', 'Muskmelon', 'Apple',
              'Orange', 'Papaya', 'Coconut', 'Cotton', 'Jute', 'Coffee']
    best_crop = labels[torch.argmax(prediction)]
    return json.dumps(best_crop)
