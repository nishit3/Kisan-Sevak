import torch
import json


def model_fn(model_dir):
    model = torch.load(r'/opt/ml/model/fertilizer_predictor.pth')
    return model


def input_fn(request_body, request_content_type):
    request_body = json.loads(request_body)
    encoding = ['Temperature', 'Humidity ', 'Moisture', 'Nitrogen', 'Potassium',
                'Phosphorous', 'CT_Barley', 'CT_Cotton',
                'CT_Ground Nuts', 'CT_Maize', 'CT_Millets',
                'CT_Oil seeds', 'CT_Paddy', 'CT_Pulses',
                'CT_Sugarcane', 'CT_Tobacco', 'CT_Wheat',
                'ST_Black', 'ST_Clayey', 'ST_Loamy',
                'ST_Red', 'ST_Sandy']
    input = [request_body['Temperature'], request_body['Humidity'], request_body['Moisture'], request_body['Nitrogen'],
             request_body['Potassium'],
             request_body['Phosphorous']]
    for i in range(6, len(encoding)):
        if encoding[i] == request_body['Crop_Type'] or encoding[i] == request_body['Soil_Type']:
            input.append(1.0)
        else:
            input.append(0.0)
    return torch.tensor(input)


def predict_fn(input_data, model):
    model.eval()
    with torch.no_grad():
        return model(input_data)


def output_fn(prediction, content_type):
    labels = ['Urea', 'DAP', '14-35-14', '28-28', '17-17-17', '20-20', '10-26-26']
    best_fertilizer = labels[torch.argmax(prediction)]
    return json.dumps(best_fertilizer)
print(torch.version)